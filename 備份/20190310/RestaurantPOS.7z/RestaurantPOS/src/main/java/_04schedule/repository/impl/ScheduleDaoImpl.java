package _04schedule.repository.impl;

public class ScheduleDaoImpl {

}
