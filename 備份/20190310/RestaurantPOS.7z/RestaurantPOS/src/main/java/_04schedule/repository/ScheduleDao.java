package _04schedule.repository;

public class ScheduleDao {

}
