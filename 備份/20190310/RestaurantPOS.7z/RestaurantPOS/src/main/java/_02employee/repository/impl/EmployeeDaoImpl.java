package _02employee.repository.impl;

public class EmployeeDaoImpl {

}
