package _02employee.repository;

public class EmployeeDao {

}
