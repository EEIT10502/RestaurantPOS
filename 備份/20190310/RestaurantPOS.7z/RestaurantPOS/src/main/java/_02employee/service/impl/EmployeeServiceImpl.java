package _02employee.service.impl;

public class EmployeeServiceImpl {

}
