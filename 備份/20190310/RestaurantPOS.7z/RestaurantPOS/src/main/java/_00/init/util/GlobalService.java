package _00.init.util;

public class GlobalService {

	//productInsert所需資料_開始
	public static final String Product_Cate_Rice = "飯類";
	public static final String Product_Cate_Soup = "湯類";
	public static final String PRODUCT_CATE_NOODLE = "麵類";
	public static final String PRODUCT_CATE_DUMPLINGS = "餃類";
	
	public static final String Product_Status_Launched_Already = "販售";
	public static final String Product_Status_No_Longer_Be_Sold = "停售";
	//productInsert所需資料_結束
	
	//product查詢所需資料_開始
	public static final int ITEMS_PER_PAGE = 2;
	//product查詢所需資料_結束
}